import csv,json,re,hashlib,zipfile
from pathlib import Path
from collections import Counter
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
P=Path(__file__).resolve().parent
D=P/'data'; OUT=P/'deliverables';OUT.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text())
blocks=read(D/'source_blocks.json'); lookup={r['record_id']:r for r in blocks}
ann=list(csv.DictReader((D/'manual_annotations.tsv').open(),delimiter='\t'))
assert len(ann)==len({a['record_id'] for a in ann})
primary=[]
for a in ann:
 r=lookup[a['record_id']]
 primary.append(dict(r,**{k:v for k,v in a.items() if k!='record_id'},language='en',review_status='본문대조_분류완료',source_url_scope='게시물 URL; 댓글은 source_lines로 위치 확인' if r['record_type']=='comment' else '게시물 URL',likes=None,reposts=None))
xspec=[
('시험','시험 종료','여행','부산 여행','미래계획','아버지의 여행 권유에 대한 계획; 실제 유예 행동의 지속 여부는 불명'),
('시험','시험 종료','문화·여행','영화 보기·여행','미래계획','실행 전 희망 목록'),
('시험','시험 종료','자기돌봄·집안일·취미','머리 자르기·옷 정리·블로그·릴스·여행 준비','미래계획','시험 뒤 할 일 목록; 항목마다 현재 못 하는 이유가 명시된 것은 아님'),
('복합조건','시험→과제→온라인 테스트','여행·취미','여행 계획·캐릭터 그리기','연쇄조건_미래계획','여러 의무 뒤에 취미를 배치한 계획; 완료 여부 불명'),
('시험','시험 종료','운동·여행','운동·여행으로 지구력 키우기','미래계획','현재도 등산한 글; 모든 운동을 중단한 사례로 읽으면 안 됨'),
('시험','시험 종료','취미·관계·여행','게임·새 사람 만나기·친구와 여행','미래보상계획','시험 뒤의 보상 계획; 실제 기다린 기간 불명'),
('외모·체중','감량','자기표현','입고 싶던 옷 입기','시작함_조건달성','감량 후 원하는 옷을 입었다는 회고'),
('저축','여행 비용 마련','여행','디즈니 여행','계획_경쟁지출','다른 가족여행 지출을 고려한 계획; 실제 연기 확정 아님')]
xexcerpt={0:'아빠가 시험 끝나면 어떻게 되든 여행 갔다 오라는데\n여행...\n....\n부산 갈까\n9월에 시간 되는 트친 있니',4:'시험 끝나면 운동 좀 하고 여행 자주 다니면서 기초적인 지구력을 좀 키워놔야겠네요.',5:'시험 끝나면 디코섭에서 하룻동안은 게임만 하고\n새로운 우인할 사람도 꼬셔서 우인 맞추고\n친구들이랑 타지로 여행도 가고'}
xpublic=[]
for i,spec in enumerate(xspec):
 d=read(P/f'raw/korean_{i}.json');md=d['result']['markdown']
 full=md.split('## Post\n\n')[1].split('\n## ')[0].strip()
 quote=xexcerpt.get(i,full)
 if len(quote.split())>25:quote=' '.join(quote.split()[:25])
 assert len(quote.split())<=25
 posted=re.search(r'Posted: (.+)',md).group(1).replace('\\','')
 likes,rt=re.search(r'Likes: ([\d,]+) \| Retweets: ([\d,]+)',md).groups()
 a,b,c,e,f,n=spec
 r=dict(record_id='X'+d['url'].split('/')[-1],platform='X',thread_id=d['url'].split('/')[-1],record_type='post',source_url=d['url'],thread_title='',community='',source_author_hash='',published_as_displayed=posted,retrieved_date='2026-11-08',original_text=quote,text_scope='원문 전체' if quote==full else '원문 일부_25단어이내',source_lines='',raw_file=f'sources/x_{i}.json',language='ko',review_status='본문대조_분류완료',source_url_scope='개별 게시물 URL',likes=int(likes.replace(',','')),reposts=int(rt.replace(',','')),출발조건_분류=a,출발조건=b,미뤄둔생활_분류=c,미뤄둔생활=e,상태=f,제약유형='불명',판독메모=n)
 primary.append(r);xpublic.append(r)
# Search discovery retains URLs, but non-Reddit text is omitted to avoid accumulating excerpts.
searches=[]; byurl={}
for file in sorted((P/'raw').glob('search_*.json')):
 d=read(file); result=d.get('result',d); web=result.get('data',{}).get('web',[])
 for s in web:
  u=s.get('url','')
  if not re.search(r'https?://(?:www\.)?(?:reddit\.com|x\.com|twitter\.com|threads\.(?:net|com))/',u): continue
  platform='Reddit' if 'reddit.com/' in u else 'X' if ('x.com/' in u or 'twitter.com/' in u) else 'Threads'
  row={'source_url':u,'platform':platform,'query':d.get('query','initial pilot'),'title':s.get('title','') if platform=='Reddit' else '', 'description':s.get('description','') if platform=='Reddit' else '', 'raw_file':str(file.relative_to(P))}
  searches.append(row)
  if u not in byurl:byurl[u]=row
# The raw retrieval archive only includes Reddit page windows; X uses these limited excerpts.
auto=read(D/'screening_candidates.json')
for r in auto:r['review_status']='자동후보_미검토';r['상태']='판독필요'
manifest=read(D/'page_manifest.json')
# Flag overlapping captured fragments, without deleting evidence or changing record IDs.
groups={}
for r in blocks:
 key=(r['thread_id'],r['source_author_hash'],r['record_type']);groups.setdefault(key,[]).append(r)
for group in groups.values():
 for r in group:
  norm=' '.join(r['original_text'].split())
  dup=next((q['record_id'] for q in group if len(q['original_text'])>len(r['original_text']) and len(norm)>=60 and norm in ' '.join(q['original_text'].split())), '')
  r['overlap_fragment_of']=dup
  r['review_status']='본문대조_분류완료' if r['record_id'] in {a['record_id'] for a in ann} else '미검토_자동분리'
  r['text_scope']='도구가 반환한 본문 블록; 전체 댓글·스레드 수집 보장 안 됨'
# Threads are discovery-only, not promoted into A/B evidence.
threads=[r for r in byurl.values() if r['platform']=='Threads']
for r in threads:r.update(review_status='검색발견_본문미확인',original_text='',상태='판독불가')
# Render flat export with strings for nested values.
def flat(x):
 return {k:json.dumps(v,ensure_ascii=False) if isinstance(v,(list,dict)) else v for k,v in x.items()}
def writecsv(name,rows):
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,keys);w.writeheader();w.writerows(flat(r) for r in rows)
for name,rows in [('검토완료_AB.csv',primary),('수집원문_자동분리.csv',blocks),('자동후보_미검토.csv',auto),('SNS_검색목록.csv',list(byurl.values()))]:writecsv(name,rows)
(OUT/'검토완료_AB.json').write_text(json.dumps(primary,ensure_ascii=False,indent=2))
(OUT/'수집원문_자동분리.json').write_text(json.dumps(blocks,ensure_ascii=False,indent=2))
stats={'검토분류완료':len(primary),'검토_Reddit':len(ann),'검토_X':len(xpublic),'원문블록_Reddit':len(blocks),'자동후보_미검토':len(auto),'검색발견_SNS_URL':len(byurl),'검색결과행_중복포함':len(searches),'검색파일수':len(list((P/'raw').glob('search_*.json'))),'Reddit_페이지반환성공':sum(r['retrieval_status']=='page_text_retrieved' for r in manifest),'Reddit_페이지요청':len(manifest),'본문블록포함_Reddit스레드':len({r['thread_id'] for r in blocks}),'중첩조각후보':sum(bool(r['overlap_fragment_of']) for r in blocks),'Threads_본문미확인_URL':len(threads)}
notes=[
('주제','조건 A를 이루면 생활 B를 시작하겠다는 SNS의 자기보고. 보편적 인간 특성을 입증한 표본이 아닙니다.'),
('수집일','2026-11-08; 검색/반환 도구가 보여 준 시점과 캐시 상태에 따른 자료입니다. 전체 SNS/전체 댓글 수집이 아닙니다.'),
('SNS 범위','Reddit, X. Threads는 검색 발견 목록만 포함하며 본문 미확인 자료는 검토완료에서 제외합니다.'),
('A','삶/활동을 시작하기 전에 필요하다고 말한 조건. 달성 가능한 목표뿐 아니라 준비됨·자신감 등도 포함합니다.'),
('B','해당 조건 뒤에 하겠다고 말한 활동. 구체적 활동과 삶 전반·행복 같은 추상적 기대를 구분합니다.'),
('상태','게시 시점의 자기보고입니다. 계획, 유예, 검토, 달성 후 시작, 조건 미달 상태의 시작, 반례, 타인 전언을 구분합니다. 현재 근황은 추적하지 않았습니다.'),
('판독의 한계','본문을 대조한 연구용 1차 분류입니다. 문장에 없는 심리를 확정하지 않습니다. 질문 맥락으로 A를 보완한 댓글은 판독메모에 표시했습니다.'),
('숫자의 단위','원문 블록은 게시물/댓글 텍스트 단위이며 사람 수가 아닙니다. 한 사람이 여러 댓글을 쓸 수 있고 페이지 일부가 겹칠 수 있습니다. overlap_fragment_of는 중첩 조각 후보입니다.'),
('검토완료의 의미','A/B와 상태를 원문과 대조해 분류했다는 뜻입니다. 모든 항목이 실제로 미루는 사람인 것은 아닙니다. 미래계획과 반례를 함께 보존했습니다.'),
('자동후보','키워드로 넓게 추출했으며 오탐이 포함됩니다. A/B 확정 사례 수에 합산하지 않습니다.'),
('원문 범위','Reddit은 반환된 텍스트 블록을 원문 그대로 보존했습니다. 댓글의 끝이 잘렸거나 UI 잔여 텍스트가 있을 수 있습니다. raw_file/source_lines로 반환문을 대조할 수 있습니다.'),
('X 원문','게시물 본문을 확인하고 25단어 이내 직접인용을 제공합니다. 일부 발췌 여부는 text_scope에 표시하며, 첨부 이미지와 후속 댓글은 분석하지 않았습니다.'),
('날짜·반응수','Reddit 상대 날짜는 화면 표기대로 보존하며 정확한 게시일로 역산하지 않았습니다. X 반응수는 반환 시점의 수치입니다. 빈 값은 미확인이고 0이 아닙니다.'),
('출처 위치','Reddit 댓글은 스레드 URL과 source_lines/raw_file을 제공하며 개별 댓글 영구 링크는 확보하지 않았습니다. X는 개별 게시물 URL입니다.'),
('편향','영어 Reddit과 체중·학업 관련 검색 비중이 높습니다. 검색 발견 방식과 분류 기준상 주제별 빈도를 인구 비율로 해석할 수 없습니다.'),
('분석 권장','먼저 검토완료_AB에서 상태=미루는중 및 구체적 생활을 골라 읽고, 조건달성후/반례를 대조하세요. 미래계획은 별도 층으로 사용하세요.'),
('개인정보','분석에 불필요한 계정명은 별도 열로 추출하지 않았습니다. 공개 원문과 출처 URL에는 개인의 자기보고가 남아 있습니다.'),
('제약유형','심리적/실질적/혼합/불명은 맥락에 대한 1차 해석입니다. 실제 자원 부족을 단순 의지 문제로 읽지 않도록 원문과 함께 검토하세요.')]
wb=Workbook();wb.remove(wb.active)
def sheet(name,rows):
 ws=wb.create_sheet(name)
 if not rows:return
 keys=list(dict.fromkeys(k for r in rows for k in r));ws.append(keys)
 for r in rows:
  vals=[]
  for k in keys:
   v=flat(r).get(k)
   if isinstance(v,str):
    v=re.sub('[\x00-\x08\x0b\x0c\x0e-\x1f]','',v)
    if v.startswith(('=','+','-','@')):v="'"+v
    if len(v)>32767:v=v[:32700]+' [Excel 제한; 전체는 JSON 참조]'
   vals.append(v)
  ws.append(vals)
 ws.freeze_panes='B2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='234C57')
 for i,k in enumerate(keys,1):
  ws.column_dimensions[get_column_letter(i)].width=72 if k in ['original_text','description','내용'] else 55 if k in ['판독메모','source_url'] else 25
 for row in ws.iter_rows(min_row=2):
  for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
  ws.row_dimensions[row[0].row].height=75 if 'original_text' in keys else 36
sheet('안내',[{'항목':k,'내용':v} for k,v in notes]+[{'항목':k,'내용':v} for k,v in stats.items()])
ordered=['record_id','platform','출발조건_분류','출발조건','미뤄둔생활_분류','미뤄둔생활','상태','제약유형','판독메모','original_text','text_scope','source_url','source_url_scope','published_as_displayed','likes','reposts','retrieved_date','record_type','thread_title','source_lines','raw_file','review_status','language']
sheet('검토완료_AB',[{k:r.get(k) for k in ordered} for r in primary])
sheet('데이터A',[{k:r.get(k) for k in ['record_id','platform','출발조건_분류','출발조건','상태','source_url']} for r in primary])
sheet('데이터B',[{k:r.get(k) for k in ['record_id','platform','미뤄둔생활_분류','미뤄둔생활','상태','source_url']} for r in primary])
sheet('자동후보_미검토',auto);sheet('수집원문_자동분리',blocks);sheet('SNS_검색목록',list(byurl.values()));sheet('Threads_본문미확인',threads);sheet('수집로그',manifest)
sheet('상태별_검토분류',[{'상태':k,'사례수':v} for k,v in Counter(r['상태'] for r in primary).most_common()])
book=OUT/'SNS_삶의출발조건_AB_1차수집.xlsx';wb.save(book)
(OUT/'수집방법과_읽는법.txt').write_text('\n\n'.join(f'{k}: {v}' for k,v in notes)+'\n\n'+json.dumps(stats,ensure_ascii=False,indent=2))
(OUT/'수집통계.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
# Share only the permitted archive contents: Reddit raw windows + limited X quotes, no full X/Threads crawl responses.
archive=P/'SNS_삶의출발조건_AB_1차수집.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in OUT.iterdir():z.write(f,'SNS_삶의출발조건_AB/'+f.name)
 for f in (P/'raw').glob('page_*.json'):z.write(f,'SNS_삶의출발조건_AB/raw/'+f.name)
 for i,r in enumerate(xpublic):z.writestr(f'SNS_삶의출발조건_AB/sources/x_{i}.json',json.dumps(r,ensure_ascii=False,indent=2))
 for f in [P/'collect_parse.py',P/'build_dataset.py',D/'manual_annotations.tsv',D/'page_manifest.json']:z.write(f,'SNS_삶의출발조건_AB/method/'+f.name)
# Validate deliverables.
assert len(primary)==136 and len({r['record_id'] for r in primary})==136
assert all(r['original_text'] and r['출발조건'] and r['미뤄둔생활'] for r in primary)
assert all(re.match(r'https://(?:www\.)?(reddit\.com|x\.com)/',r['source_url']) for r in primary)
check=load_workbook(book,read_only=True)
assert check['검토완료_AB'].max_row==137
check.close()
print(json.dumps(stats,ensure_ascii=False,indent=2));print('XLSX',book);print('ZIP',archive)
