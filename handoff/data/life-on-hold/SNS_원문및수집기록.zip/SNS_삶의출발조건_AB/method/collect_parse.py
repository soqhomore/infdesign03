import json,re,hashlib,pathlib
ROOT=pathlib.Path(__file__).parent
RAW=ROOT/'raw'
DATA=ROOT/'data'
def clean(s):
    s=re.sub(r'【\d+†([^†】]+)(?:†[^】]*)?】',r'\1',s)
    return s.strip()
records=[]; pages=[]
for f in sorted(RAW.glob('page_*.json')):
    d=json.loads(f.read_text()); raw=d['tool_response']
    numbered=[(int(m.group(1)),m.group(2)) for m in re.finditer(r'^L(\d+): ?(.*)$',raw,re.M)]
    if not numbered:
        pages.append({**{k:v for k,v in d.items() if k!='tool_response'},'retrieval_status':'failed','raw_file':str(f.relative_to(ROOT))})
        continue
    cutoff=next((i for i,(_,t) in enumerate(numbered) if t.startswith('# More posts') or t.startswith('## Top Posts')),len(numbered))
    lines=numbered[:cutoff]
    title_idx=next((i for i,(n,t) in enumerate(lines) if n<150 and t.startswith('# ') and not t.startswith('# Comments')),None)
    page_id=re.search(r'/comments/([^/]+)',d['url']).group(1)
    pages.append({**{k:v for k,v in d.items() if k!='tool_response'},'retrieval_status':'page_text_retrieved','raw_file':str(f.relative_to(ROOT)),'visible_line_count':len(lines),'reported_total_lines':int(re.search(r'Total lines: (\d+)',raw).group(1)) if re.search(r'Total lines: (\d+)',raw) else None})
    def add(kind,txt,a,b,author='',date=''):
        txt=txt.strip()
        if len(txt)<12 or 'I am a bot' in txt or author=='AutoModerator':return
        if txt.startswith('Comment deleted') or txt.startswith('[Removed]'):return
        h=hashlib.sha256((page_id+'|'+kind+'|'+author+'|'+re.sub(r'\s+',' ',txt)).encode()).hexdigest()[:14]
        records.append({'record_id':'S'+h,'platform':'Reddit','thread_id':page_id,'record_type':kind,'source_url':d['url'],'thread_title':d['title'],'community':re.search(r'/r/([^/]+)',d['url']).group(1),'source_author_hash':hashlib.sha256(author.encode()).hexdigest()[:12] if author else '', 'published_as_displayed':date,'retrieved_date':'2026-11-08','original_text':txt,'text_scope':'retrieved_source_block','source_lines':f'L{a}-L{b}','raw_file':str(f.relative_to(ROOT))})
    if title_idx is not None:
        end=next((i for i in range(title_idx+1,len(lines)) if '†Share】' in lines[i][1] or re.fullmatch(r'(?:Share\s*){1,3}',clean(lines[i][1])) or lines[i][1].strip() in ['Sort by:','# Comments Section'] or lines[i][1].startswith('Archived post.')),len(lines))
        body=[]
        for n,t in lines[title_idx+1:end]:
            if re.fullmatch(r'【\d+†[^】]+】',t) or t.startswith('[') and t.endswith(']'):continue
            body.append((n,clean(t)))
        author=clean(lines[title_idx-1][1]) if title_idx else ''
        date=next((clean(t).lstrip('• ') for n,t in lines[max(0,title_idx-6):title_idx] if ' ago' in t),'')
        if body:add('post','\n'.join(t for n,t in body),body[0][0],body[-1][0],author,date)
    starts=[]
    for i,(n,t) in enumerate(lines):
        m=re.fullmatch(r'【\d+†([^†】]+)】',t)
        if (not m and t not in ['[deleted]','[removed]']) or n<22 or (title_idx is not None and i<=title_idx):continue
        who=m.group(1) if m else t
        if re.search(r'\bago\b|more repl|Image|Comments|Log In|Q&A|Share|^r/',who):continue
        date_i=next((j for j in range(i+1,min(i+8,len(lines))) if len(clean(lines[j][1]))<100 and re.search(r'\b\d+(?:y|mo|d|h|m|w| yr\.?| days?| months?| years?) ago\b',clean(lines[j][1]))),None)
        if date_i is not None:starts.append((i,date_i,who))
    for k,(i,di,who) in enumerate(starts):
        end=starts[k+1][0] if k+1<len(starts) else len(lines)
        body=[]
        for n,t in lines[di+1:end]:
            if re.fullmatch(r'【\d+†[^】]+】',t) or t in ['•','more reply','more replies','[deleted]']:continue
            if t.startswith('# Comments'):continue
            body.append((n,clean(t)))
        if body:add('comment','\n'.join(t for n,t in body),body[0][0],body[-1][0],who,clean(lines[di][1]))
seen=set();out=[]
for r in records:
    k=re.sub(r'\s+',' ',r['original_text']).strip().casefold()
    if k in seen:continue
    seen.add(k);out.append(r)
DATA.mkdir(exist_ok=True)
(DATA/'source_blocks.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
(DATA/'page_manifest.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2))
trigger=re.compile(r'\b(?:until|once|after|when|before|wait\w*|postpon\w*|put\w* off|on hold|retir\w*)\b',re.I)
personal=re.compile(r'\b(?:I|my|me|we|our)\b',re.I)
possible=[]
for r in out:
    t=r['original_text']
    if trigger.search(t) and personal.search(t):
        r['trigger_sentences']=[s for s in re.split(r'(?<=[.!?])\s+|\n+',t) if trigger.search(s)]
        possible.append(r)
(DATA/'screening_candidates.json').write_text(json.dumps(possible,ensure_ascii=False,indent=2))
print(json.dumps({'pages':len(pages),'retrieved_pages':sum(p['retrieval_status']=='page_text_retrieved' for p in pages),'source_blocks':len(out),'screening_candidates':len(possible)},ensure_ascii=False))
